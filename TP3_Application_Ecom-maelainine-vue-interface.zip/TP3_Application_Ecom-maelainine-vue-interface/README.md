# TP3_Application_Ecom

### Veuiller consulter le PDF `GitHub_collaboration_cheatsheet.pdf` sur la façon dont on peut être structuré dans les git (add, commit, push, branch...)